package com.amarsoft.app.pidr.index;

/**
 * task执行状态类
 * @author yyzang
 *
 */
public class TaskInfo {

	private String inputDate;
	private int count;
	
	public TaskInfo() {
		super();
		// TODO Auto-generated constructor stub
	}
	public String getInputDate() {
		return inputDate;
	}
	public void setInputDate(String inputDate) {
		this.inputDate = inputDate;
	}
	public int getCount() {
		return count;
	}
	public void setCount(int count) {
		this.count = count;
	}

	
}
