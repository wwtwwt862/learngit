#!/bin/sh
sh startup.sh datacopy
