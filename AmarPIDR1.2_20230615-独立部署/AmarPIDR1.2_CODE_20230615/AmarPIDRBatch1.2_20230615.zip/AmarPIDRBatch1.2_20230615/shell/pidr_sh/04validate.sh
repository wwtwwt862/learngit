#!/bin/sh
sh startup.sh validate
