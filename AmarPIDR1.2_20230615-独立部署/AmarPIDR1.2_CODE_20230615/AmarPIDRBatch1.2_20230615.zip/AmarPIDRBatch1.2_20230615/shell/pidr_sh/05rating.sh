#!/bin/sh
sh startup.sh rating
