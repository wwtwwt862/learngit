#!/bin/sh
sh startup.sh transfer
