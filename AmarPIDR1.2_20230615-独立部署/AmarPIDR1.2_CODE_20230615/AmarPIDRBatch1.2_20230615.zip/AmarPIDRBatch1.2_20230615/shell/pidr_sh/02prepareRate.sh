#!/bin/sh
sh startup.sh preparerate
