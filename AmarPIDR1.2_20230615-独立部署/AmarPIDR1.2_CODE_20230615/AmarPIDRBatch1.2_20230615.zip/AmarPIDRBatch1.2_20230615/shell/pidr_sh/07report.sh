#!/bin/sh
sh startup.sh report
