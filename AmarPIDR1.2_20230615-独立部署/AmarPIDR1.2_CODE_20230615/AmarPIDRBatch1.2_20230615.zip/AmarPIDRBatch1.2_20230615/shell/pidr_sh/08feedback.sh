#!/bin/sh
sh startup.sh feedback
