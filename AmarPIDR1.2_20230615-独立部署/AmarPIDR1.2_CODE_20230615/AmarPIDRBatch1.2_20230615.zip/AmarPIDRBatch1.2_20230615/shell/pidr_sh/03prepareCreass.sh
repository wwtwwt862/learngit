#!/bin/sh
sh startup.sh preparecreass
